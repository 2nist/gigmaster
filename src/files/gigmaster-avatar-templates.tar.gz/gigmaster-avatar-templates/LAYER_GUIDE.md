# Layer Structure Guide for GIMP/Photoshop

## How to Use This Template

### In GIMP (Free):
1. Open GIMP
2. File → New → 512×512 pixels, Fill with Transparency
3. Create layer groups as shown below
4. Import the PNG templates as guide layers (lock them)
5. Create your art on separate layers
6. Export individual layers as PNG-24

### In Photoshop:
1. File → New → 512×512 pixels, Transparent background
2. Create layer groups as shown below
3. Import PNG templates as guide layers (lock them)
4. Create art on separate layers
5. File → Export → Quick Export as PNG (for each layer)

## Recommended Layer Structure

```
📁 GigMaster Avatar [512×512px]
│
├── 📁 GUIDES (Lock this group, don't export)
│   ├── 🔒 Grid & Safe Zones
│   ├── 🔒 Anchor Points
│   └── 🔒 Reference Template
│
├── 📁 EFFECTS-FOREGROUND [Export: effect-*.png]
│   ├── Sparkles
│   ├── Musical Notes
│   └── Glow Overlay
│
├── 📁 ACCESSORIES [Export: acc-*.png]
│   ├── Headphones
│   ├── Sunglasses
│   ├── Hat
│   └── Earrings
│
├── 📁 HAIR-FRONT [Export: hair-front-*.png]
│   ├── Bangs Layer
│   └── Front Strands
│
├── 📁 MOUTH [Export: mouth-*.png]
│   ├── Smile
│   ├── Neutral
│   └── Open
│
├── 📁 EYES [Export: eyes-*.png]
│   ├── Pupils
│   ├── Iris
│   ├── Highlights
│   └── Eyelids
│
├── 📁 HAIR-BACK [Export: hair-back-*.png]
│   ├── Back Volume
│   └── Side Coverage
│
├── 📁 FACE [Export: body-*.png or face-*.png]
│   ├── Skin Tone
│   ├── Face Shape
│   └── Neck
│
├── 📁 BODY-DETAILS [Export: combine with body]
│   ├── Clothing
│   ├── Tattoos
│   └── Texture
│
├── 📁 BODY-BASE [Export: body-*.png]
│   ├── Torso
│   ├── Shoulders
│   └── Shadow/Shading
│
└── 📁 EFFECTS-BACKGROUND [Export: effect-*.png]
    ├── Aura
    ├── Glow
    └── Background Pattern

```

## Export Workflow

### For GIMP:

1. **Hide all layers except the one you want to export**
2. Image → Flatten Image (or don't, if you want to keep transparency)
3. File → Export As
4. Choose PNG
5. Save to: `public/avatar/assets/{category}/{filename}.png`
6. Undo flatten (Edit → Undo)
7. Repeat for each layer

**GIMP Script-Fu Batch Export:**
```python
# Save this as export-layers.scm in GIMP scripts folder
# Filters → Script-Fu → Export Layers to Files

(define (export-layers image)
  (let* ((layers (gimp-image-get-layers image)))
    (for-each
      (lambda (layer)
        (gimp-file-save RUN-NONINTERACTIVE
          image layer
          (string-append "layer-" (gimp-layer-get-name layer) ".png")
          (gimp-layer-get-name layer)))
      (vector->list layers))))
```

### For Photoshop:

**Quick Export Method:**
1. Right-click layer → Quick Export as PNG
2. Rename to match convention

**Batch Export Script:**
```javascript
// File → Scripts → Browse → Select this .jsx file

var doc = app.activeDocument;
var layers = doc.layers;
var outputFolder = Folder.selectDialog("Select output folder");

for (var i = 0; i < layers.length; i++) {
    var layer = layers[i];
    
    // Hide all layers
    for (var j = 0; j < layers.length; j++) {
        layers[j].visible = false;
    }
    
    // Show only current layer
    layer.visible = true;
    
    // Export
    var file = new File(outputFolder + "/" + layer.name + ".png");
    var pngOptions = new PNGSaveOptions();
    pngOptions.compression = 9;
    doc.saveAs(file, pngOptions, true);
}

// Show all layers again
for (var j = 0; j < layers.length; j++) {
    layers[j].visible = true;
}

alert("Export complete!");
```

## Color Palette Swatches

### Skin Tones
```
Light:   #FFDAB9 (peachpuff)
Medium:  #D2B48C (tan)
Dark:    #8B4513 (saddlebrown)
Fantasy: #7CFC00 (alien green)
Zombie:  #9ACD32 (yellowgreen)
```

### Hair Colors
```
Black:    #2C1810
Brown:    #8B4513
Blonde:   #FFD700
Red:      #DC143C
Auburn:   #A52A2A

Fantasy:
Hot Pink: #FF1493
Cyan:     #00CED1
Purple:   #9370DB
Lime:     #32CD32
White:    #F0F8FF
```

### Eye Colors
```
Brown:  #8B4513
Blue:   #4169E1
Green:  #228B22
Hazel:  #8B7355
Grey:   #708090
```

### Accessory/Detail Colors
```
Gold:   #FFD700
Silver: #C0C0C0
Black:  #000000
Red:    #FF0000
Blue:   #0000FF
```

## Tips for Each Asset Type

### Body
- Use soft gradients for depth
- Keep edges clean
- Leave face area transparent
- Add subtle shading on sides

### Eyes
- Always include a highlight (small white dot)
- Iris should have some texture/variation
- Pupils should be consistent size
- Eyelids for blink frames

### Hair
- Use multiple layers for depth
- Back layer: fuller, wider
- Front layer: wispy, detail strands
- Don't be afraid of bold colors
- Add highlights for shine

### Accessories
- High contrast (stand out)
- Clean silhouettes
- Test with multiple hair styles
- Keep them optional (transparent background)

### Effects
- Use LOW opacity (30-60%)
- Larger canvas coverage okay
- Subtle is better than flashy
- Test layering order

## Testing Checklist

After creating each asset:

- [ ] Canvas is 512×512px
- [ ] Background is fully transparent
- [ ] No stray pixels outside safe zone
- [ ] Colors are vibrant (not muddy)
- [ ] Saved as PNG-24 with alpha
- [ ] File named correctly
- [ ] File size reasonable (<100KB)
- [ ] Tested in avatar preview
- [ ] Works with other assets

## Common Mistakes to Avoid

❌ **Don't:**
- Use JPG format (no transparency)
- Leave white backgrounds
- Make details too small (won't scale)
- Forget to hide guide layers before export
- Use effects that rely on specific backgrounds
- Make asymmetric elements (unless intentional)

✅ **Do:**
- Save frequently
- Keep original layered files
- Use version control (v1, v2, etc.)
- Test combinations early
- Get feedback from others
- Start simple, add detail later

## Quick Start Workflow

**Day 1: Setup**
1. Choose your tool (GIMP/Photoshop/Krita)
2. Open body template
3. Create 3 skin tones
4. Export and test

**Day 2: Features**
1. Open eyes template
2. Create 5 eye variations
3. Open mouth template
4. Create 3 mouth expressions
5. Export and test

**Day 3: Hair**
1. Open hair template
2. Create 3 hair styles (back + front for each)
3. Try different colors
4. Export and test

**Day 4: Polish**
1. Add accessories (2-3 items)
2. Add one effect
3. Test all combinations
4. Refine based on what works

**Day 5: Expand**
- Add more variations
- Create archetype-specific items
- Add animation frames (blink, etc.)

---

Remember: **Quantity over quality at first.** Get 20 okay assets before perfecting 5 great ones. You'll learn what works through iteration!
