# GigMaster Avatar Quick Start Cheat Sheet

## TL;DR - Get Started in 5 Minutes

### Step 1: Choose Your Tool
- **GIMP** (Free): Download from gimp.org
- **Photopea** (Free, Browser): photopea.com
- **Photoshop** (Paid): If you already have it

### Step 2: Set Up Canvas
```
Size: 512×512 pixels
Background: Transparent
Color Mode: RGB
Resolution: 72 DPI
```

### Step 3: Import Template
- Open: `templates/TEMPLATE_body.png` (or whichever asset you're making)
- Lock this layer (it's just a guide)
- Create new layer above it
- Draw your asset

### Step 4: Export
```
Format: PNG-24
Transparency: Yes
File name: {category}-{variant}.png
Example: body-light.png, eyes-normal-brown.png
Save to: public/avatar/assets/{category}/
```

### Step 5: Test
```bash
node tools/build-avatar-manifest.js
# Refresh your avatar demo
```

---

## Essential Dimensions (Memorize These)

| Element | Position (x, y) | Size |
|---------|----------------|------|
| Canvas | - | 512×512px |
| Safe Zone | 32px margin | 448×448px |
| Head Circle | (256, 180) | 120px diameter |
| Left Eye | (226, 160) | 30×20px |
| Right Eye | (286, 160) | 30×20px |
| Mouth | (256, 200) | 50×20px |
| Anchor Point | (256, 480) | - |

---

## Asset Priority Order (Make These First)

### Week 1: Minimum Viable Avatar
1. ✅ Body (3 skin tones)
   - body-light.png
   - body-medium.png
   - body-dark.png

2. ✅ Eyes (3 colors)
   - eyes-normal-brown.png
   - eyes-normal-blue.png
   - eyes-normal-green.png

3. ✅ Mouth (2 expressions)
   - mouth-smile.png
   - mouth-neutral.png

4. ✅ Hair (2 styles × 2 colors)
   - hair-front-spiky-black.png
   - hair-back-spiky-black.png
   - hair-front-long-brown.png
   - hair-back-long-brown.png

**Total: 14 files = ~100 unique avatar combinations**

### Week 2: Personality
5. ✅ More Hair (3 more styles × 3 colors)
6. ✅ Accessories (3 items)
   - acc-headphones-dj.png
   - acc-sunglasses-rock.png
   - acc-hat-beanie.png

**Total: +30 files = 1000s of combinations**

---

## Color Codes (Copy-Paste Ready)

### Skin Tones
```
Light:    #FFDAB9
Medium:   #D2B48C
Dark:     #8B4513
Fantasy:  #7CFC00 (alien)
```

### Hair (Natural)
```
Black:    #2C1810
Brown:    #8B4513
Blonde:   #FFD700
Red:      #DC143C
```

### Hair (Fantasy)
```
Hot Pink: #FF1493
Cyan:     #00CED1
Purple:   #9370DB
Lime:     #32CD32
```

### Eyes
```
Brown:  #8B4513
Blue:   #4169E1
Green:  #228B22
Grey:   #708090
```

---

## Common Mistakes - Troubleshooting

### "My asset doesn't show up!"
- ❌ Did you forget to run `build-avatar-manifest.js`?
- ❌ Is the file actually PNG-24 with transparency?
- ❌ Is it in the right folder? (`public/avatar/assets/{category}/`)
- ❌ Is the filename following the naming convention?

### "The layers don't line up!"
- ❌ Did you use the template guides?
- ❌ Is your canvas exactly 512×512px?
- ❌ Are you centering things at (256, y)?

### "The colors look washed out!"
- ❌ Did you use RGB mode? (not CMYK)
- ❌ Are you using vibrant hex codes?
- ❌ Did you accidentally apply a low opacity?

### "File size is huge!"
- ❌ Did you flatten all the guide layers into it?
- ❌ Are you saving as PNG-24 (not PNG-48)?
- Target: <100KB per asset

---

## Keyboard Shortcuts Reference

### GIMP
```
New Layer:        Shift+Ctrl+N
Export:           Shift+Ctrl+E
Eyedropper:       O
Fill:             Shift+Ctrl+;
Merge Down:       Ctrl+M
Hide/Show Layer:  Click eye icon
```

### Photoshop
```
New Layer:        Shift+Ctrl+N
Export:           Shift+Ctrl+Alt+W
Eyedropper:       I
Fill:             Shift+F5
Merge Down:       Ctrl+E
Hide/Show Layer:  Click eye icon
```

---

## File Organization (In Your Editor)

```
💾 gigmaster-avatar-work/
├── 📁 source-files/          ← Keep your layered files here
│   ├── body-master.xcf       (GIMP)
│   ├── eyes-master.psd       (Photoshop)
│   └── hair-master.kra       (Krita)
│
├── 📁 exports/               ← Export PNGs here first
│   ├── body-light.png
│   ├── body-medium.png
│   └── ...
│
└── 📁 references/            ← Inspiration & guides
    ├── template_body.png
    └── color-palette.png
```

Then copy from `exports/` → `your-repo/public/avatar/assets/`

---

## Daily Workflow

### Morning (30 min)
1. Pick ONE asset category (e.g., "hair")
2. Open template
3. Create 2-3 variants
4. Export as PNG
5. Test in game

### Afternoon (20 min)
1. Refine based on what you saw
2. Add color variations
3. Export & test again

### Evening (10 min)
1. Try random combinations
2. Note what looks good/bad
3. Plan tomorrow's assets

**Goal: 5-10 new assets per day = fully stocked in 2 weeks**

---

## Quality Checklist (Before Export)

- [ ] Canvas is 512×512px
- [ ] Background is transparent
- [ ] Guide layers are hidden/deleted
- [ ] Colors match hex codes above
- [ ] Anti-aliasing is smooth
- [ ] No stray pixels
- [ ] Filename follows convention
- [ ] Saved as PNG-24

---

## When to Move to Advanced Features

**Stick with simple PNGs until:**
- ✅ You have 50+ assets
- ✅ Load times are slow (>2 seconds)
- ✅ You want complex animations

**Then consider:**
- Sprite atlases (TexturePacker)
- Animation frames
- Normal maps for lighting

---

## Getting Unstuck

**"I can't draw!"**
→ Use AI generation (Midjourney, DALL-E)
→ Trace over photo references
→ Start with geometric shapes
→ Copy the example assets and modify

**"I don't know what to make!"**
→ Look at your favorite games
→ Google "pixel art character sprite"
→ Check out music game characters
→ Make your friends as avatars

**"This is taking forever!"**
→ Lower your quality bar
→ Reuse/recolor existing assets
→ Focus on variety over perfection
→ Time-box each asset (15 min max)

---

## Pro Tips

💡 **Batch create**: Make all skin tones at once, all eye colors at once
💡 **Reuse shapes**: Copy-paste base shapes, just change colors
💡 **Test early**: Don't make 50 assets before testing the first one
💡 **Version control**: Save as v1, v2, v3 so you can roll back
💡 **Get feedback**: Show friends/team every few days

---

## Success Metrics

After 1 week:
- [ ] 10+ working assets
- [ ] At least 3 complete combinations look good
- [ ] Avatar generates in <1 second

After 2 weeks:
- [ ] 50+ assets
- [ ] Every random generation looks acceptable
- [ ] Happy with overall quality

After 1 month:
- [ ] 100+ assets
- [ ] Archetype-specific collections
- [ ] Ready to show players!

---

**Remember: Ship it fast, iterate based on feedback. Perfect is the enemy of done!** 🚀
