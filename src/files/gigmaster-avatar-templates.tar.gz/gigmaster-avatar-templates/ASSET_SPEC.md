# GigMaster Avatar Asset Specification

## Canvas Specifications

### Base Dimensions
- **Canvas Size**: 512×512 pixels
- **Export Format**: PNG-24 with alpha transparency
- **Color Mode**: RGB
- **Resolution**: 72 DPI (web standard)

### Safe Zones
```
┌─────────────────────────┐
│     Top Margin: 32px    │
├─────────────────────────┤
│ L:32px  CONTENT   R:32px│
│                         │
│    Character Zone       │
│    448×448 pixels       │
│                         │
├─────────────────────────┤
│   Bottom Margin: 32px   │
└─────────────────────────┘
```

### Anchor Point System
- **Origin**: Center-bottom of canvas (256px, 480px)
- **Body anchor**: Aligns at feet/bottom
- **Head anchor**: Relative to body top
- **Eyes anchor**: Relative to head center
- **Hair/Accessories**: Relative to head top

## Layer Structure & Z-Index

Render order (back to front):
1. **Background Effects** (z: 0) - Optional glow/aura
2. **Body Base** (z: 10) - Main character silhouette
3. **Body Details** (z: 20) - Clothing, tattoos
4. **Face Base** (z: 30) - Skin tone
5. **Eyes** (z: 40) - Eye graphics
6. **Mouth** (z: 50) - Expression
7. **Hair Back** (z: 35) - Hair behind head
8. **Hair Front** (z: 60) - Hair over forehead
9. **Accessories** (z: 70) - Glasses, headphones, hats
10. **Foreground Effects** (z: 80) - Sparkles, notes

## Asset Categories & Guidelines

### 1. Body Base (`body/`)
**Purpose**: Main character silhouette and skin tone

**Variants Needed**:
- `body-light.png`
- `body-medium.png`
- `body-dark.png`
- `body-alien-green.png` (fantasy archetype)

**Design Guidelines**:
- Simple silhouette, no complex details
- Shoulders should be at ~200px from bottom
- Head area: circle roughly 120px diameter centered at (256, 180)
- Leave face area transparent for layering
- Include basic neck/shoulders

**Reference Dimensions**:
```
Head circle: 120×120px at (196, 120)
Neck width: 40px
Shoulder width: 180px
Total height: ~400px (leaving room for hair)
```

### 2. Eyes (`eyes/`)
**Purpose**: Character expression and personality

**Variants Needed**:
- `eyes-normal-brown.png`
- `eyes-normal-blue.png`
- `eyes-normal-green.png`
- `eyes-wide-excited.png`
- `eyes-squint-focused.png`
- `eyes-closed-blink.png` (for animation)

**Design Guidelines**:
- Eye pair centered at (256, 160)
- Spacing between eyes: 60-80px
- Each eye approx 30×20px
- Include highlights for life
- Blink frame: just eyelids

**Position Reference**:
```
Left eye center: (226, 160)
Right eye center: (286, 160)
Pupil size: 12×12px
Highlight: 4×4px white dot
```

### 3. Mouth (`mouth/`)
**Purpose**: Expression and future lip-sync

**Variants Needed**:
- `mouth-smile.png`
- `mouth-neutral.png`
- `mouth-open-singing.png`
- `mouth-wide-excited.png`

**Design Guidelines**:
- Centered at (256, 200)
- Width: 40-60px
- Simple shapes work best
- Leave room for animation frames

**Phoneme Frames** (future):
- `mouth-ah.png` (A, I)
- `mouth-ee.png` (E)
- `mouth-oh.png` (O)
- `mouth-oo.png` (U)
- `mouth-m.png` (M, B, P)

### 4. Hair (`hair/`)
**Purpose**: Primary visual identity

**Variants Needed**:
- Back layer (`hair-back-*.png`)
- Front layer (`hair-front-*.png`)

**Style Examples**:
- `hair-spiky` - Punk/Rock
- `hair-long` - Metal/Classical
- `hair-afro` - Funk/Soul
- `hair-mohawk` - Punk
- `hair-bald` - Clean
- `hair-dreads` - Reggae/Hip-hop

**Design Guidelines**:
- Back layer: behind head, shows on sides
- Front layer: over forehead, bangs
- Maximum height: 100px above head
- Use vibrant colors for personality
- Keep edges clean for compositing

**Color Palette**:
```
Natural: #2C1810 (black), #8B4513 (brown), #FFD700 (blonde), #DC143C (red)
Fantasy: #FF1493 (hot pink), #00CED1 (cyan), #9370DB (purple), #32CD32 (lime)
```

### 5. Accessories (`accessories/`)
**Purpose**: Musician personality and archetype

**Variants Needed**:
- `acc-headphones-dj.png`
- `acc-sunglasses-rock.png`
- `acc-hat-fedora.png`
- `acc-hat-beanie.png`
- `acc-earrings.png`
- `acc-microphone.png`

**Design Guidelines**:
- Must work with multiple hair styles
- Position guides:
  - Headphones: over ears, (256, 160)
  - Glasses: over eyes, (256, 160)
  - Hats: top of head, (256, 100)
- Use complementary colors
- Keep it simple - max 3 colors per accessory

### 6. Effects (`effects/`)
**Purpose**: Visual flair and archetype reinforcement

**Variants Needed**:
- `effect-aura-gold.png` (background)
- `effect-notes-floating.png` (foreground)
- `effect-sparkles.png` (foreground)
- `effect-glow-blue.png` (background)

**Design Guidelines**:
- Low opacity (30-60%)
- Subtle animations possible
- Should enhance, not distract
- Full canvas size (512×512)

## Archetype-Specific Themes

### Rock Star
- Colors: Black, red, silver
- Hair: Spiky, mohawk
- Accessories: Sunglasses, leather
- Effect: Red glow

### DJ/Electronic
- Colors: Cyan, purple, neon
- Hair: Modern cuts, colored
- Accessories: Headphones (essential)
- Effect: Blue glow, geometric shapes

### Jazz/Classical
- Colors: Earth tones, gold
- Hair: Classic, refined
- Accessories: Bow tie, fedora
- Effect: Golden aura

### Hip-Hop
- Colors: Bold, urban palette
- Hair: Dreads, fades, caps
- Accessories: Chains, caps
- Effect: Sparkles, bling

## File Naming Convention

```
{category}-{style}-{variant}.png

Examples:
body-light.png
eyes-normal-blue.png
hair-front-spiky-red.png
hair-back-spiky-red.png
acc-headphones-dj.png
effect-aura-gold.png
```

## Export Checklist

Before exporting each asset:

- [ ] Canvas is exactly 512×512px
- [ ] Background is transparent
- [ ] File format is PNG-24
- [ ] No layers are hidden accidentally
- [ ] Anchor point aligns correctly
- [ ] Colors are vibrant (not washed out)
- [ ] Anti-aliasing is smooth
- [ ] File size is reasonable (<100KB per asset)
- [ ] Naming follows convention
- [ ] Saved in correct category folder

## Testing Your Assets

After creating assets:

1. Drop into `public/avatar/assets/{category}/`
2. Run `node tools/build-avatar-manifest.js`
3. Refresh avatar demo
4. Test with multiple seeds
5. Verify layering works correctly
6. Check all combinations look good

## Quality Standards

### Do's ✅
- Use clean, bold shapes
- High contrast for readability
- Consistent style across all assets
- Test at multiple scales
- Leave breathing room around elements

### Don'ts ❌
- Overly detailed textures (won't scale)
- Muddy colors (low contrast)
- Asymmetric elements (unless intentional)
- Forgetting transparency
- Inconsistent lighting direction

## Recommended Tools

### Free
- **GIMP** - Full-featured, template included
- **Krita** - Great for digital art
- **Photopea** - Browser-based Photoshop clone
- **Aseprite** - Pixel art (if going retro style)

### Paid
- **Photoshop** - Industry standard, PSD template included
- **Procreate** - iPad illustration
- **Affinity Photo** - One-time purchase

### AI-Assisted
- **Midjourney** → Export → Clean up in GIMP/Photoshop
- **DALL-E** → Same workflow
- **Stable Diffusion** (local) → Full control

## Next Steps

1. Choose your design tool
2. Open the appropriate template (PSD/XCF/SVG)
3. Start with 3 body tones
4. Add 5 hair styles
5. Create 3 eye variations
6. Test in-game
7. Iterate based on what works!

Remember: **Start simple, iterate fast.** You can always add more detail later.
